from flipkart_root import Scrapper
import amazonscraper


def banner():
    print("""                                            
  ########     #######   #####   ##          #######    #########   ##       ##########   ##########    ##########
  ##      ##   ##       #     #  ##          ##             ##      ##           ##       ##            ##      ##
  ##       ##  ##       #     #  ##          ##             ##      ##           ##       ##            ##      ##
  ##        ## #####    #######  ##          #####          ##      ##           ##       #######       ##########       #
  ##       ##  ##       #     #  ##          ##             ##      ##           ##       ##            ## ##
  ##      ##   ##       #     #  ##          ##             ##      ##           ##       ##            ##  ##
  ########     #######  #     #  #######     ##         #########   ########     ##       ##########    ##   ###
  """)
    print ("Press 1 for Amazon")
    print ("Press 2 for Flipkart")
   

def main():
    choice = int(input())
    if choice == 1 :
        
        x=input("enter the product ")

        results = amazonscraper.search(x, max_product_nb=10)

        for result in results:
            print("{}".format(result.title))
            print("  - ASIN : {}".format(result.asin))
            print("  - {} out of 5 stars, {} customer reviews".format(result.rating, result.review_nb))
            print("  - {}".format(result.url))
            print("  - Image : {}".format(result.img))
            print("  - price : {}".format(result.price))
            print()

        print("Number of results : %d" % (len(results)))


    elif choice == 2:
        print('Enter item you want to search:')
        search = input()
        obj = Scrapper(search)


        def write_to_excel(dataframe):
            dataframe.to_excel('test.xlsx', sheet_name='sheet1', index=False)
            
            return dataframe


        df = obj.initialize()
       # df.transpose()
        write_to_excel(df)

        
   

if __name__=='__main__':
        
        banner()
        main()
        
        

              
