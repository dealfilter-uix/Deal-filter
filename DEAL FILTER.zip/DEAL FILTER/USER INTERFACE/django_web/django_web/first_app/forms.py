from django import forms

class FormName(forms.Form):
    FirstName=forms.CharField()
    LastName=forms.CharField()
    EmailAddress=forms.EmailField()
    PhoneNumber=forms.CharField()
    Pincode=forms.CharField()
    Subject=forms.CharField(widget=forms.Textarea)
