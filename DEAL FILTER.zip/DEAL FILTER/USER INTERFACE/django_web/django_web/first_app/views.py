from django.shortcuts import render
from django.http import HttpResponse
from . import forms

# Create your views here
def index(request):
    return render(request,'index.html')

def sign_up_view(request):








    return render(request,'sign_up_form.html')
